/* Structured body IR, one lexical traversal per logical statement.
 * Columns: quote, indent, colon, equals, tab, trailing-space, byte length,
 * parent statement, exclusive block end, significant flag, head-end, stack.
 * Last column is construction scratch; no source/result lookup is retained.
 */
#include <stdint.h>
typedef uint64_t U;
U syntax_statement_build_native(U *lines,U *out){
 U n=lines[1],*v=out+2,depth=0;out[0]=(U)lines;out[1]=n;
 for(U i=0;i<n;i++){
  const unsigned char*s=(void*)lines[i+2];U j=0,ind=0,col=(U)-1,eq=(U)-1,quote=(U)-1,tab=0;
  int inside=0,leading=1;
  while(s[j]){
   unsigned c=s[j];if(leading){if(c==' ')ind++;else leading=0;}
   if(inside){if(c=='\\'&&s[j+1])j++;else if(c=='"')inside=0;}
   else if(c=='\t')tab=1;else if(c=='"'){inside=1;if(quote==(U)-1)quote=j;}
   else if(c==':'&&col==(U)-1)col=j;else if(c=='='&&eq==(U)-1)eq=j;
   j++;
  }
  v[i]=quote;v[n+i]=ind;v[2*n+i]=col;v[3*n+i]=eq;v[4*n+i]=tab;
  v[5*n+i]=j&&s[j-1]<33;v[6*n+i]=j;
  U first=ind;while(first<j&&s[first]<=32)first++;
  U head=first;while(head<j&&s[head]>32&&s[head]!=':'&&s[head]!='(')head++;
  v[10*n+i]=head;v[9*n+i]=first<j&&s[first]!='#';
  v[7*n+i]=(U)-1;v[8*n+i]=n;
  if(v[9*n+i]){
   while(depth){U parent=v[11*n+depth-1];if(v[n+parent]<ind)break;v[8*n+parent]=i;depth--;}
   if(depth)v[7*n+i]=v[11*n+depth-1];
   v[11*n+depth++]=i;
  }
 }
 U bad=0;for(U i=0;i<n;i++){bad+=v[4*n+i]!=0;v[11*n+i]=bad;}
 return n;
}
