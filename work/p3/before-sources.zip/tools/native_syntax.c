/* Linux expression frontend. Single cursor lexer + precedence parser.
 * Nodes and parser state belong exclusively to the caller's active arena.
 * No external calls, static mutable state, source-keyed lookup or saved result.
 */
#include <stdint.h>
typedef uint64_t U;
typedef struct { U kind,start,end,left,right; } Node;
enum { CALL=256, ARG=257, EQ=300,NE,LE,GE,SHL,SAR,SHR,LAND,LOR };
enum { POS=8,TOK,START,END,DEPTH,BAD };
#define INLINE static __attribute__((always_inline)) inline
INLINE int word(unsigned c){return c=='_'||(c>='0'&&c<='9')||(c>='A'&&c<='Z')||(c>='a'&&c<='z');}
INLINE int digit(unsigned c){return c>='0'&&c<='9';}
INLINE int prec(U c){
 if(c==LOR)return 1;if(c==LAND)return 2;if(c=='|')return 3;
 if(c=='^')return 4;if(c=='&')return 5;if(c==EQ)return 6;
 if(c==NE)return 7;if(c==LE)return 8;if(c==GE)return 9;
 if(c=='<')return 10;if(c=='>')return 11;if(c==SHR)return 12;
 if(c==SAR)return 13;if(c==SHL)return 14;
 if(c=='+'||c=='-')return 15;if(c=='*'||c=='/'||c=='%')return 16;return 0;
}
INLINE Node *nodes(U*h){return (Node*)(h+16);}
INLINE U add(U*h,U k,U s,U e,U l,U r){
 U id=h[2]++;if(id>h[1]){h[BAD]=1;return 0;}
 nodes(h)[id]=(Node){k,s,e,l,r};return id;
}
INLINE void next(U*h){
 const unsigned char*s=(void*)h[0];U n=h[1],i=h[POS];
 while(i<n&&s[i]<=32)i++;
 h[START]=i;h[TOK]=0;if(i==n){h[END]=i;h[POS]=i;return;}
 unsigned c=s[i++];U kind=c;
 if(word(c)){
  kind=digit(c)?2:1;while(i<n&&word(s[i]))i++;
  if(kind==2){
   U a=h[START];int hex=i>a+2&&s[a]=='0'&&(s[a+1]=='x'||s[a+1]=='b');
   if(!hex)for(U j=a;j<i;j++)if(!digit(s[j]))h[BAD]=1;
  }
 }else if(c=='"'){
  kind=3;int closed=0;
  while(i<n){unsigned b=s[i++];if(b=='\\'){if(i<n)i++;else break;}else if(b=='"'){closed=1;break;}}
  if(!closed)h[BAD]=1;
 }else if(i<n){
  unsigned d=s[i];
  if(c=='='&&d=='='){kind=EQ;i++;}else if(c=='!'&&d=='='){kind=NE;i++;}
  else if(c=='<'&&d=='='){kind=LE;i++;}else if(c=='>'&&d=='='){kind=GE;i++;}
  else if(c=='<'&&d=='<'){kind=SHL;i++;}else if(c=='>'&&d=='>'){kind=SAR;i++;if(i<n&&s[i]=='>'){kind=SHR;i++;}}
  else if(c=='&'&&d=='&'){kind=LAND;i++;}else if(c=='|'&&d=='|'){kind=LOR;i++;}
 }
 h[TOK]=kind;h[END]=i;h[POS]=i;
}
static U expression(U*h,int minimum){
 if(h[BAD])return 0;
 if(++h[DEPTH]>150){h[BAD]=1;h[DEPTH]--;return 0;}
 U kind=h[TOK],start=h[START],end=h[END],root=0;int text_head=0;
 if(kind==1||kind==2||kind==3){
  root=add(h,0,start,end,(U)-1,(U)-1);text_head=kind==3;next(h);
  if(kind==1&&h[TOK]=='('){
   U callee=root,first=(U)-1,last=(U)-1;next(h);
   if(h[TOK]!=')')for(;;){
    U arg=expression(h,1);if(h[BAD])break;
    U link=add(h,ARG,nodes(h)[arg].start,nodes(h)[arg].end,arg,(U)-1);
    if(last!=(U)-1)nodes(h)[last].right=link;else first=link;last=link;
    if(h[TOK]!=',')break;next(h);
   }
   if(h[TOK]!=')')h[BAD]=1;
   root=add(h,CALL,start,h[END],callee,first);h[5]++;next(h);
  }
 }else if(kind=='('){
  next(h);root=expression(h,1);if(h[TOK]!=')')h[BAD]=1;
  nodes(h)[root].start=start;nodes(h)[root].end=h[END];next(h);
 }else if(kind=='-'){
  next(h);if(h[TOK]!=2)h[BAD]=1;
  root=add(h,0,start,h[END],(U)-1,(U)-1);next(h);
 }else h[BAD]=1;
 while(!h[BAD]){
  int p=prec(h[TOK]);if(!p||p<minimum)break;
  /* Legacy text-head recognizer claims a whole quoted surface. Decline
   * instead of silently changing that compatibility rule into pointer math. */
  if(text_head){h[BAD]=1;break;}
  U op=h[TOK];next(h);U right=expression(h,p+1);
  root=add(h,op,nodes(h)[root].start,nodes(h)[right].end,root,right);h[5]++;
 }
 h[DEPTH]--;return root;
}
uintptr_t syntax_build_native(const unsigned char*s,U n,U*h){
 if(n<1||n>4096)return 0;
 h[0]=(U)s;h[1]=n;for(int i=2;i<16;i++)h[i]=0;
 next(h);U root=expression(h,1);
 if(h[BAD]||h[TOK]||!h[5])return 0;
 h[6]=root;return (uintptr_t)h;
}
