"""Exercise extracted shared routines inside the working Linux compiler."""
import argparse,hashlib,json,pathlib,subprocess

def sha(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def smoke(args,cwd,label,timeout,folder):
    try:
        result=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,timeout=timeout)
        return {'exit_code':result.returncode,'failure_reason':None,
                'diagnostic_stdout':result.stdout.decode(errors='replace')[:65536],
                'diagnostic_stderr':result.stderr.decode(errors='replace')[:65536]}
    except subprocess.TimeoutExpired:
        return {'exit_code':124,'failure_reason':'timeout','diagnostic_stdout':'','diagnostic_stderr':''}

REPORT_PATH=None
def save(name,value):
    if REPORT_PATH:
        REPORT_PATH.parent.mkdir(parents=True,exist_ok=True)
        REPORT_PATH.write_text(json.dumps(value,indent=2)+'\n')

PROBE = '''    if argc is 4
        if _sov_str_eq(peek_ptr(argv, 1), "--prefilter-regression") is 1
            pt_capacity: _sov_atoi(peek_ptr(argv, 2))
            pd_ucap: pt_capacity
            pd_umsk: pt_capacity - 1
            pd_uk: _sov_heap_alloc(pt_capacity * 8 + 16)
            _sov_bzero(pd_uk, pt_capacity * 8 + 16)
            poke_i64(pd_uk, pt_capacity * 8, 1234567)
            pt_names: _sov_list_new()
            pti: 0
            as long as _sov_list_len(pt_names) < 3
                ptn: join("wrap_name_", strip(i2s(pti)))
                if band(nhash(ptn), pd_umsk) is pd_umsk
                    pt_names: _sov_list_add(pt_names, ptn)
                pti: pti + 1
            pti: 0
            as long as pti < 3
                ptn: peek_i64(pt_names, 16 + pti * 8)
                fresh: cut(join(ptn, "!"), 0, length(ptn))
                print fresh is not ptn
                pd_u_put(ptn)
                pd_u_put(fresh)
                print pd_u_has(fresh)
                pti: pti + 1
            print peek_i64(pd_uk, pt_capacity * 8) is 1234567
            print _sov_str_eq(peek_i64(pd_uk, pd_umsk * 8), peek_i64(pt_names, 16))
            print _sov_str_eq(peek_i64(pd_uk, 0), peek_i64(pt_names, 24))
            print _sov_str_eq(peek_i64(pd_uk, 8), peek_i64(pt_names, 32))
            print pd_is_task_header("# fake:") is 0
            print pd_is_task_header("task value:") is 1
            print pd_is_task_header("") is 0
            print pd_is_task_header("x: 7") is 0
            snap_m: 0
            source: "main:\\n    return 7\\nused_library:\\n    return 2\\n"
            sf_pu_txt: 0
            sf_pu_ls: 0
            result: prune_dead(source, 0, "/nonexistent-sovren-prefilter-input")
            print _sov_str_eq(result, source)
            print result is source
            source: "# fake:\\nmain:\\n    return 7\\nunused:\\n    return 3\\n"
            result: prune_dead(source, 0, "/nonexistent-sovren-prefilter-input")
            print _sov_str_eq(result, source)
            print had_err is 0
            user_path: peek_ptr(argv, 3)
            source: "main:\\n    return used_library()\\nused_library:\\n    return 7\\n"
            result: prune_dead(source, 0, user_path)
            print _sov_str_eq(result, source)
            print result is source
            source: "main:\\n    return used_library()\\nused_library:\\n    return 7\\nunused_library:\\n    return 3\\n"
            result: prune_dead(source, 0, user_path)
            print look(result, "used_library:") >= 0
            print look(result, "unused_library:") < 0
            print _sov_list_len(lines_of(source)) is _sov_list_len(sg_pu_ls)
            generated: _sov_list_new()
            generated: _sov_list_add(generated, "main:")
            generated: _sov_list_add(generated, "    return 7")
            count: 0
            as long as count < 20000
                name: join("task_", strip(i2s(count)))
                generated: _sov_list_add(generated, join(name, ":"))
                generated: _sov_list_add(generated, "    return 3")
                count: count + 1
            source: sg_text(generated)
            result: prune_dead(source, 0, "/nonexistent-sovren-prefilter-input")
            print pd_umsk is 131071
            print result is source
            syscall(60, 0)
'''

def main():
    global REPORT_PATH
    parser=argparse.ArgumentParser(description='Linux integration of shared prefilter bounds, string equality and source ownership')
    parser.add_argument('--compiler',default='compilers/linux/compiler')
    parser.add_argument('--output')
    args=parser.parse_args()
    project=pathlib.Path(__file__).resolve().parents[2]
    folder=project/'work/regression-prefilter'
    REPORT_PATH=pathlib.Path(args.output) if args.output else folder/'result.json' 
    folder.mkdir(parents=True,exist_ok=True)
    driver=project/'compilers/linux/compiler.sov';original=driver.read_text()
    shared=project/'compilers/shared/ccore.sov';cc=(project/args.compiler).resolve()
    section=shared.read_text().split('pd_lines_result text ls:\n',1)[1]
    section='pd_lines_result text ls:\n'+section
    # Build using the selected compiler, then enter the diagnostic branch
    # before the hybrid's normal translation path. The shared routines are
    # exercised directly; the hybrid is not used as a general compiler.
    section=section.replace('sf_pu_txt','sg_pu_txt').replace('sf_pu_ls','sg_pu_ls').replace('sf_text','sg_text')
    start=original.index('pd_lines_result text ls:\n');end=original.index('delegate_core ',start)
    debugtext=original[:start]+section+'\n'+original[end:]
    probe=PROBE.replace('sf_pu_txt','sg_pu_txt').replace('sf_pu_ls','sg_pu_ls')
    debugtext=debugtext.replace('main argc argv:\n','main argc argv:\n'+probe,1)
    diagnostic=folder/'compiler-probe';temp=driver.parent/'prefilter-regression-driver.sov'
    user=folder/'user.sov';user.write_text('main:\n    return used_library()\n')
    assert not temp.exists()
    report={'schema':1,'shared_source_sha256':sha(shared),'selected_compiler_sha256':sha(cc),
            'no_translation_result_cache':True,'full_parity_complete':False,
            'scope':'Extracted shared routines with existing Linux helper dependencies; not full fleet validation',
            'checks':[]}
    try:
        temp.write_text(debugtext)
        build=smoke([cc,temp,'-o',diagnostic],project,'probe-build',40,folder=folder)
        report['build']=build;assert build['exit_code']==0 and diagnostic.is_file(),build
        for capacity in [16,1024,131072]:
            q=smoke([diagnostic,'--prefilter-regression',str(capacity),user],project,'probe-'+str(capacity),20,folder=folder)
            lines=q['diagnostic_stdout'].splitlines();passed=q['exit_code']==0 and lines==['1']*25
            report['checks'].append({'capacity':capacity,'result':q,'passed':passed})
            save('SOVREN_SHARED_PREFILTER_QUALIFICATION.json',report)
            print(capacity,lines,'passed',passed,flush=True)
            assert passed,q
        report['passed']=True
    finally:
        temp.unlink(missing_ok=True)
        save('SOVREN_SHARED_PREFILTER_QUALIFICATION.json',report)
    print('Shared bounds, equality, headers and zero-drop source ownership pass.',flush=True)

if __name__=='__main__':main()
