#!/usr/bin/env python3
"""Exception dispatch, immutable names and repeat lowering across syntax modes."""
import argparse,json,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
CASES=[
 ('try-no-raise','main:\n    try\n        print 1\n    except e\n        print 9\n    print 2\n','1\n2\n'),
 ('try-caught','main:\n    try\n        raise 42\n    except e\n        print e\n    print 2\n','42\n2\n'),
 ('try-call','boom:\n    raise 5\n    return 0\nmain:\n    try\n        boom()\n    except e\n        print e\n    print 2\n','5\n2\n'),
 ('try-nested','main:\n    try\n        try\n            raise 1\n        except a\n            print a\n        raise 2\n    except b\n        print b\n    print 7\n','1\n2\n7\n'),
 ('try-last','main:\n    try\n        b: 5\n        print b\n    except e\n        print 9\n','5\n'),
 ('try-without-except','main:\n    try\n        print 1\n',None),
 ('except-without-try','main:\n    except e\n        print e\n',None),
 ('immutable-reassign','main:\n    immutable n: 5\n    n: 6\n    print n\n',None),
 ('immutable-explicit','main:\n    immutable n: 5\n    n := n + 1\n    print n\n',None),
 ('repeat-lowering','main:\n    repeat 3 times\n        print 1\n','1\n1\n1\n'),
]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--compiler',default='compilers/linux/compiler');ap.add_argument('--output');a=ap.parse_args()
 cc=(ROOT/a.compiler).resolve();results=[]
 with tempfile.TemporaryDirectory(prefix='sovren-semantics-') as td:
  td=Path(td)
  for name,text,want in CASES:
   src=td/'source.sov';src.write_text(text)
   for flags in [[],['--syntax-reference'],['--legacy-syntax'],['--syntax-tree'],['--no-dce'],['--plain']]:
    out=td/'program';out.unlink(missing_ok=True)
    q=subprocess.run([cc,src,*flags,'-o',out],cwd=ROOT,capture_output=True,timeout=20)
    passed=q.returncode!=0 if want is None else False
    if want is not None and q.returncode==0 and out.is_file():
     run=subprocess.run([out],cwd=ROOT,capture_output=True,timeout=5)
     passed=run.returncode==0 and run.stdout.decode()==want and run.stderr==b''
    results.append({'case':name,'flags':flags,'passed':passed})
    assert passed,(name,flags,q.returncode,q.stdout.decode(errors='replace'),q.stderr.decode(errors='replace'))
 report={'schema':1,'passed':len(results),'total':len(results),'results':results}
 if a.output:Path(a.output).write_text(json.dumps(report,indent=2)+'\n')
 print('PASS',len(results),'exception/immutability/repeat checks; six modes')
if __name__=='__main__':main()
