#!/usr/bin/env python3
"""Fresh builds and target-aware correctness evidence for the retained fleet.

Structural checks alone never count as repaired. Foreign executables are not
run on Linux. A compiler generation must actually run and produce correct
fixtures; missing output and failed runs cannot form a fixed point.
"""
import argparse
import hashlib
import json
import os
import pathlib
import platform
import re
import shutil
import struct
import subprocess
import tempfile

FIXTURES = {
    'return': ('main:\n    return 7\n', '', 7),
    'arithmetic': ('main:\n    x: 17 * 23\n    print x\n', '391\n', 0),
    'loop': ('main:\n    i: 0\n    as long as i < 3\n        print i\n        i: i + 1\n', '0\n1\n2\n', 0),
    'call': ('twice x:\n    return x * 2\nmain:\n    print twice(21)\n', '42\n', 0),
}

def sha(path):
    with pathlib.Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def source_identity(root):
    digest = hashlib.sha256(); count = 0
    for directory in ('compilers', 'library'):
        for path in sorted((root/directory).rglob('*.sov')):
            digest.update(path.relative_to(root).as_posix().encode()+b'\0')
            digest.update(bytes.fromhex(sha(path))); count += 1
    return {'sha256':digest.hexdigest(),'files':count}

def run(command, cwd, timeout=120):
    try:
        q = subprocess.run(list(map(str, command)), cwd=cwd, capture_output=True,
                           timeout=timeout, stdin=subprocess.DEVNULL)
        return {'exit_code': q.returncode,
                'stdout': q.stdout.decode(errors='replace')[-16000:],
                'stderr': q.stderr.decode(errors='replace')[-16000:]}
    except subprocess.TimeoutExpired:
        return {'exit_code': 124, 'stdout': '', 'stderr': 'timeout'}
    except OSError as error:
        return {'exit_code': None, 'stdout': '', 'stderr': str(error)}

def contract(target):
    if target.startswith('webassembly/'):
        variant = target.split('/')[-1]
        return {'kind': 'html' if variant in ('browser', 'emscripten') else
                'js' if variant == 'edge' else
                'wat' if variant == 'webassembly-text' else
                'component' if variant == 'component-model' else 'wasm',
                'os': 'webassembly', 'architecture': 'wasm64' if 'wasm64' in variant else 'wasm32'}
    if target.startswith('apple/'):
        variant = target.split('/')[-1]
        platforms = {'macos': 1, 'macos-arm64': 1, 'ios': 2, 'tvos': 3,
                     'watchos': 4, 'ios-simulator': 7, 'tvos-simulator': 8,
                     'watchos-simulator': 9, 'visionos': 11, 'visionos-simulator': 12,
                     'arm64e': 2, 'arm64_32': 4}
        return {'kind': 'macho', 'os': 'darwin',
                'architecture': 'x86_64' if variant == 'macos' else 'arm64',
                'cpu': 0x01000007 if variant == 'macos' else
                       0x0200000c if variant == 'arm64_32' else 0x0100000c,
                'platform': platforms[variant]}
    if target.startswith('windows'):
        return {'kind': 'pe', 'os': 'windows', 'architecture': 'x86_64', 'machine': 0x8664}
    if target == 'operating-systems/menuetos':
        return {'kind': 'menuet', 'os': 'menuetos', 'architecture': 'x86_64'}
    if target == 'operating-systems/sovrenos':
        # The 2026-11-11 regeneration replaced the SXE stub driver with the
        # full bridged ELF driver (tools/build_bsd_port.py --target sovrenos).
        return {'kind': 'elf', 'os': 'sovrenos', 'architecture': 'x86_64',
                'machine': 62, 'osabi': (0,), 'library': False}
    name = target.split('/')[-1] if target.startswith('operating-systems/') else 'android' if target.startswith('android') else 'linux'
    brands = {'linux': (0, 3), 'android': (0, 3), 'freebsd': (9,),
              'dragonfly': (0,), 'netbsd': (2,), 'openbsd': (0, 12),
              'illumos': (6,), 'haiku': (0, 5), 'qnx': (0,), 'redox': (0,), 'serenityos': (0,)}
    arm = target.startswith('android') or 'arm64' in target
    return {'kind': 'elf', 'os': name, 'architecture': 'aarch64' if arm else 'x86_64',
            'machine': 183 if arm else 62, 'osabi': brands[name],
            'library': target.endswith('shared-object')}

def leb(data, at):
    result = 0
    for shift in range(0, 70, 7):
        if at >= len(data): raise ValueError('truncated LEB')
        byte = data[at]; at += 1; result |= (byte & 127) << shift
        if byte < 128: return result, at
    raise ValueError('overflowing LEB')

def sections(data):
    at = 8
    result = []
    while at < len(data):
        kind = data[at]; size, start = leb(data, at + 1); end = start + size
        if end > len(data): raise ValueError('section outside image')
        result.append((kind, data[start:end])); at = end
    return result

def wasm_bytes(data, expected):
    if expected['kind'] in ('html', 'js'):
        text = data.decode()
        match = re.search(r'new Uint8Array\(\[([\d,\s]+)\]\)', text)
        if not match: raise ValueError('HTML has no embedded wasm module')
        if 'env' not in text or 'sovren_print' not in text:
            raise ValueError('HTML wrapper does not supply the module print import')
        return bytes(int(v) for v in match[1].split(',') if v.strip())
    if expected['kind'] == 'wat':
        import wasmtime
        return wasmtime.wat2wasm(data.decode())
    if expected['kind'] == 'component':
        if data[:8] != b'\0asm\x0d\0\x01\0': raise ValueError('wrong component header')
        ss = sections(data)
        if not any(k == 1 for k, _ in ss) or not any(k == 11 for k, _ in ss):
            raise ValueError('component has no core module and executable exports')
        return data
    return data

def inspect(path, expected):
    facts = {'valid': False, 'expected': expected}
    try:
        data = pathlib.Path(path).read_bytes()
        facts.update(bytes=len(data), sha256=sha(path))
        kind = expected['kind']
        if kind == 'elf':
            if len(data) < 64 or data[:6] != b'\x7fELF\x02\x01': raise ValueError('not little-endian ELF64')
            etype, machine, version, entry, phoff, shoff, flags, ehsize, phsize, phnum = struct.unpack_from('<HHIQQQIHHH', data, 16)
            facts.update(kind='elf', machine=machine, osabi=data[7], elf_type=etype)
            if machine != expected['machine'] or data[7] not in expected['osabi']:
                raise ValueError('ELF CPU or OS branding differs from target')
            if version != 1 or ehsize != 64 or phsize != 56 or not phnum:
                raise ValueError('invalid ELF header or program table')
            if etype not in ((3,) if expected['library'] else (2, 3)):
                raise ValueError('wrong executable/shared-object ELF type')
            if phoff + phsize * phnum > len(data): raise ValueError('truncated program table')
            executable = []; loads = []
            for i in range(phnum):
                ptype, perms, off, address, physical, filesz, memsz, align = struct.unpack_from('<IIQQQQQQ', data, phoff + i * phsize)
                if off + filesz > len(data) or filesz > memsz: raise ValueError('segment outside file or memory')
                if ptype == 1:
                    loads.append((address, memsz))
                    if align > 1 and ((align & (align - 1)) or (off - address) % align):
                        raise ValueError('misaligned load segment')
                    if perms & 1 and filesz: executable.append((address, filesz))
            if not executable: raise ValueError('no executable payload')
            if not expected['library'] and not any(a <= entry < a + n for a, n in executable):
                raise ValueError('entry is outside executable bytes')
        elif kind == 'macho':
            ilp32 = expected['cpu'] == 0x0200000c
            header_size = 28 if ilp32 else 32
            magic = b'\xce\xfa\xed\xfe' if ilp32 else b'\xcf\xfa\xed\xfe'
            if len(data) < header_size or data[:4] != magic: raise ValueError('wrong Mach-O header width')
            cpu, subtype, filetype, ncmds, sizeofcmds = struct.unpack_from('<IIIII', data, 4)
            if ilp32 and subtype != 1: raise ValueError('wrong arm64_32 CPU subtype')
            if cpu != expected['cpu'] or filetype != 2: raise ValueError('wrong Mach-O CPU or file type')
            if header_size + sizeofcmds > len(data): raise ValueError('load commands exceed image')
            at = header_size; segments = []; platform_id = None; entryoff = None; thread_entry = None
            for _ in range(ncmds):
                cmd, size = struct.unpack_from('<II', data, at)
                if size < 8 or at + size > header_size + sizeofcmds: raise ValueError('invalid Mach-O command size')
                if cmd in (1, 0x19):
                    if cmd != (1 if ilp32 else 0x19): raise ValueError('wrong segment command width')
                    if size < (56 if ilp32 else 72): raise ValueError('truncated segment command')
                    address, memsz, off, filesz, maxprot, initprot = struct.unpack_from('<IIIIII' if ilp32 else '<QQQQII', data, at + 24)
                    if off + filesz > len(data) or filesz > memsz: raise ValueError('segment outside image')
                    if initprot & 4 and filesz: segments.append((off, filesz, address))
                if cmd == 0x32: platform_id = struct.unpack_from('<I', data, at + 8)[0]
                if cmd == 0x80000028: entryoff = struct.unpack_from('<Q', data, at + 8)[0]
                if cmd == 5:
                    if size < 16: raise ValueError('truncated thread entry command')
                    flavor,count = struct.unpack_from('<II',data,at+8)
                    if cpu == 0x01000007 and flavor == 4 and count == 42 and size == 184:
                        thread_entry = struct.unpack_from('<Q',data,at+144)[0]
                    elif cpu in (0x0100000c,0x0200000c) and flavor == 6 and count == 68 and size == 288:
                        thread_entry = struct.unpack_from('<Q',data,at+272)[0]
                    else: raise ValueError('wrong native thread state')
                at += size
            if at != header_size + sizeofcmds: raise ValueError('command count and size disagree')
            if platform_id != expected['platform']: raise ValueError('missing or wrong Apple build platform')
            valid_main = entryoff is not None and any(a <= entryoff < a+n for a,n,v in segments)
            valid_thread = thread_entry is not None and any(v <= thread_entry < v+n for a,n,v in segments)
            if not (valid_main or valid_thread):
                raise ValueError('entry is outside executable segment')
            facts.update(kind='macho', cpu=cpu, subtype=subtype, header_bits=32 if ilp32 else 64, platform=platform_id,
                         entry_command='LC_UNIXTHREAD' if valid_thread else 'LC_MAIN')
        elif kind == 'pe':
            if len(data) < 64 or data[:2] != b'MZ': raise ValueError('missing DOS header')
            at = struct.unpack_from('<I', data, 60)[0]
            if at + 24 > len(data) or data[at:at+4] != b'PE\0\0': raise ValueError('invalid PE header')
            machine, nsec = struct.unpack_from('<HH', data, at+4)
            optsize = struct.unpack_from('<H', data, at+20)[0]
            if machine != expected['machine'] or struct.unpack_from('<H', data, at+24)[0] != 0x20b:
                raise ValueError('wrong PE CPU or optional header')
            entry = struct.unpack_from('<I', data, at+40)[0]; executable = []
            for i in range(nsec):
                pos = at + 24 + optsize + 40*i
                vsize, rva, size, off = struct.unpack_from('<IIII', data, pos+8)
                perms = struct.unpack_from('<I', data, pos+36)[0]
                if off + size > len(data): raise ValueError('PE section outside file')
                if perms & 0x20000000 and size: executable.append((rva, min(size, vsize)))
            if not any(a <= entry < a+n for a,n in executable): raise ValueError('PE entry outside executable bytes')
            facts.update(kind='pe', machine=machine)
        elif kind == 'component':
            import wasmtime
            from wasmtime.component import Component
            wasm_bytes(data, expected)
            cfg = wasmtime.Config(); cfg.wasm_component_model = True
            component = Component(wasmtime.Engine(cfg), data)
            if component.get_export_index('main') is None: raise ValueError('no callable component main')
            facts.update(kind='component')
        elif kind in ('wasm', 'wat', 'html', 'js'):
            module = wasm_bytes(data, expected)
            if len(module) <= 8 or module[:8] != b'\0asm\x01\0\0\0': raise ValueError('invalid or empty wasm module')
            import wasmtime
            cfg = wasmtime.Config(); cfg.wasm_memory64 = True; cfg.wasm_threads = True; cfg.shared_memory = True
            engine = wasmtime.Engine(cfg); mod = wasmtime.Module(engine, module)
            if not any(e.name in ('main', '_start') for e in mod.exports): raise ValueError('no callable module entry')
            facts.update(kind=kind)
        elif kind == 'menuet':
            if data[:8] != b'MENUET02' or len(data) <= 40: raise ValueError('missing MenuetOS64 executable header/payload')
        elif kind == 'sxe':
            if data[:4] != b'SXE\0' or len(data) <= 4096: raise ValueError('missing SovrenOS SXE executable/payload')
        else: raise ValueError('unknown target format')
        facts['valid'] = True
    except Exception as error:
        facts['error'] = str(error)
    return facts

ROOT = pathlib.Path(__file__).resolve().parents[2]

def aarch64_runner(expected):
    if expected.get('machine') != 183 or expected['os'] not in ('linux','android'):
        return None
    qemu = shutil.which('qemu-aarch64')
    if not qemu: return None
    if not expected.get('library'): return [qemu]
    compiler = shutil.which('aarch64-linux-gnu-gcc')
    sysroot = pathlib.Path('/usr/aarch64-linux-gnu')
    if not compiler or not (sysroot/'lib/ld-linux-aarch64.so.1').is_file(): return None
    folder = ROOT/'work/repair';folder.mkdir(parents=True,exist_ok=True)
    source = ROOT/'tests/gates/aarch64_so_loader.c'
    binary = folder/'aarch64-so-loader'
    q = run([compiler,source,'-o',binary,'-ldl'],ROOT)
    if q['exit_code'] != 0: return None
    return [qemu,'-L',sysroot,binary]

def execute(path, expected, cwd, stdout_expect, exit_expect, argv=None):
    if expected.get('machine') == 183 and expected['os'] in ('linux','android'):
        runner = aarch64_runner(expected)
        if runner is None:
            return {'executed':False,'matched':False,'pending':'AArch64 QEMU or shared-library loader unavailable'}
        pathlib.Path(path).chmod(0o700)
        q = run([*runner,path,*list(argv or [])],cwd,240)
        return {**q,'executed':q['exit_code'] is not None and q['exit_code'] != 124,
                'matched':q['exit_code'] == exit_expect and q['stdout'] == stdout_expect,
                'execution':'QEMU AArch64 and real Linux kernel; dlopen for shared objects',
                'native_platform_validated':False}
    if expected['os'] == 'webassembly':
        try:
            if expected['kind'] in ('html', 'js'):
                q = run(['node', pathlib.Path(__file__).with_name('check_wasm_wrapper.mjs'), path, expected['kind']], cwd)
                result = json.loads(q['stdout'])
                result['matched'] = (q['exit_code'] == 0 and result.get('executed')
                                     and result.get('stdout') == stdout_expect
                                     and result.get('exit_code') == exit_expect)
                return result
            import wasmtime
            if expected['kind'] == 'component':
                from wasmtime.component import Component, Linker
                cfg = wasmtime.Config(); cfg.wasm_component_model = True; cfg.consume_fuel = True
                engine = wasmtime.Engine(cfg); store = wasmtime.Store(engine); store.set_fuel(10000000)
                component = Component.from_file(engine, path); linker = Linker(engine); printed = []
                with linker.root() as instance:
                    instance.add_func('sovren-print', lambda store, n: printed.append(str(n)+'\n'))
                instance = linker.instantiate(store, component); func = instance.get_func(store, 'main')
                status = func(store); func.post_return(store); stdout = ''.join(printed)
                return {'executed':True,'exit_code':status,'stdout':stdout,
                        'matched':status == exit_expect and stdout == stdout_expect,
                        'execution':'Wasmtime 50 component runtime; correctness only'}
            cfg = wasmtime.Config(); cfg.wasm_memory64 = True; cfg.wasm_threads = True; cfg.shared_memory = True; cfg.consume_fuel = True
            engine = wasmtime.Engine(cfg); store = wasmtime.Store(engine); store.set_fuel(10000000)
            module = wasmtime.Module(engine, wasm_bytes(pathlib.Path(path).read_bytes(), expected))
            linker = wasmtime.Linker(engine); printed = []
            linker.define_func('env', 'sovren_print', wasmtime.FuncType([wasmtime.ValType.i32()], []), lambda n: printed.append(str(n)+'\n'))
            output = pathlib.Path(cwd)/'wasi.stdout'; errors = pathlib.Path(cwd)/'wasi.stderr'
            wasi = wasmtime.WasiConfig(); wasi.stdout_file = str(output); wasi.stderr_file = str(errors); store.set_wasi(wasi); linker.define_wasi()
            instance = linker.instantiate(store, module); exports = instance.exports(store)
            if '_start' in exports:
                status = 0
                try: exports['_start'](store)
                except wasmtime.ExitTrap as error: status = error.code
                stdout = output.read_text() if output.is_file() else ''
            else:
                status = exports['main'](store) or 0; stdout = ''.join(printed)
            return {'executed': True, 'stdout': stdout, 'exit_code': status,
                    'matched': stdout == stdout_expect and status == exit_expect,
                    'execution': 'Wasmtime 50; correctness only'}
        except Exception as error:
            return {'executed': False, 'matched': False, 'error': str(error)}
    native_os = 'windows' if os.name == 'nt' else 'darwin' if platform.system() == 'Darwin' else 'linux'
    native_arch = {'AMD64': 'x86_64', 'arm64': 'aarch64'}.get(platform.machine(), platform.machine())
    if expected['kind'] == 'elf' and expected['os'] not in ('linux',):
        # x86-64 foreign-OS ELFs execute on this host through the project's
        # own interpreter (library/x86.sov + library/x86os.sov syscall
        # translation), so output checks are real, not structural.
        runner = ROOT / 'library' / 'x86run.sov'
        built = ROOT / 'work' / 'repair' / 'x86run'
        stale = not built.is_file()
        if not stale:
            for dep in (runner, ROOT / 'library' / 'x86.sov', ROOT / 'library' / 'x86os.sov'):
                if built.stat().st_mtime < dep.stat().st_mtime:
                    stale = True
        if stale:
            os.makedirs(built.parent, exist_ok=True)
            q0 = run([str(ROOT / 'compilers/linux/compiler'), str(runner), '-o', str(built)], ROOT, 300)
            assert q0['exit_code'] == 0, 'cannot build the in-tree x86 runner'
        built.chmod(0o700)
        q = run([str(built), '--os=' + expected['os'], str(path)] + list(argv or []), cwd, 240)
        return {**q, 'executed': q['exit_code'] is not None and q['exit_code'] != 124,
                'matched': q['exit_code'] == exit_expect and q['stdout'] == stdout_expect,
                'execution': 'in-tree x86 interpreter (library/x86.sov) with pinned per-OS syscall tables (library/x86os.sov)'}
    if expected['kind'] == 'macho' and expected['os'] == 'darwin':
        runner = ROOT / 'work' / 'repair' / 'x86run'
        source = ROOT / 'library' / 'x86run.sov'
        stale = not runner.is_file()
        if not stale:
            for dep in (source, ROOT / 'library' / 'x86.sov'):
                if runner.stat().st_mtime < dep.stat().st_mtime:
                    stale = True
        if stale:
            os.makedirs(runner.parent, exist_ok=True)
            q0 = run([str(ROOT / 'compilers/linux/compiler'), str(source), '-o', str(runner)], ROOT, 300)
            assert q0['exit_code'] == 0, 'cannot build the in-tree x86 runner'
        runner.chmod(0o700)
        q = run([str(runner), str(path)] + list(argv or []), cwd, 240)
        return {**q, 'executed': q['exit_code'] is not None and q['exit_code'] != 124,
                'matched': q['exit_code'] == exit_expect and q['stdout'] == stdout_expect,
                'execution': 'in-tree x86 interpreter (library/x86.sov) Mach-O loader'}
    if expected['os'] != native_os or expected['architecture'] != native_arch or expected.get('library'):
        return {'executed': False, 'matched': False, 'pending': 'intended-platform runtime or shared-library loader'}
    pathlib.Path(path).chmod(0o700)
    q = run([path], cwd)
    return {**q, 'executed': q['exit_code'] is not None and q['exit_code'] != 124,
            'matched': q['exit_code'] == exit_expect and q['stdout'] == stdout_expect}

def check(root, bootstrap, entry, temporary):
    target = entry['id']; expected = contract(target)
    record = {'id': target, 'source': entry['source'], 'contract': expected,
              'build': False, 'reproducible': False, 'output_correct': False,
              'self_correct': False, 'repaired': False}
    source = root/entry['source']; record['source_sha256'] = sha(source)
    # Keep runtime and helper siblings next to the fresh driver. A target never
    # gains a Linux runtime by losing its target runtime during staging.
    local = temporary/'kit'
    shutil.copytree(source.parent, local, ignore=shutil.ignore_patterns('compiler', '*.exe'))
    first, second = local/'gate-a', local/'gate-b'
    q = run([bootstrap, source, '-o', first], root, 600); record['build_command'] = q
    if q['exit_code'] != 0 or not first.is_file(): return record
    host = {'kind': 'elf', 'os': 'linux', 'architecture': 'x86_64', 'machine': 62, 'osabi': (0,3), 'library': False}
    record['driver'] = inspect(first, host)
    if not record['driver']['valid']: return record
    first.chmod(0o700); record['build'] = True
    q2 = run([bootstrap, source, '-o', second], root, 600)
    record['reproducible'] = q2['exit_code'] == 0 and second.is_file() and sha(first) == sha(second)
    rows = []
    for name, (text, stdout_expect, exit_expect) in FIXTURES.items():
        fixture = temporary/(name+'.sov'); fixture.write_text(text)
        output = temporary/(name+'.image'); row = {'case': name}
        row['build'] = run([first, fixture, '-o', output], root)
        row['artifact'] = inspect(output, expected) if row['build']['exit_code'] == 0 and output.is_file() else {'valid': False, 'error': 'compile failed or missing output'}
        row['execution'] = execute(output, expected, temporary, stdout_expect, exit_expect) if row['artifact']['valid'] else {'matched': False, 'executed': False}
        rows.append(row)
    record['fixtures'] = rows
    record['output_correct'] = all(r['artifact']['valid'] and r['execution']['matched'] for r in rows)
    self1, self2 = temporary/'self1', temporary/'self2'
    record['self_build'] = run([first, source, '-o', self1], root, 600)
    if record['self_build']['exit_code'] == 0 and self1.is_file():
        record['self_artifact'] = inspect(self1, expected)
        q = run([first, source, '-o', self2], root, 600)
        record['self_reproducible'] = q['exit_code'] == 0 and self2.is_file() and sha(self1) == sha(self2)
        if ((expected['os'] == 'linux' and expected['architecture'] == 'x86_64' and not expected.get('library')) or aarch64_runner(expected) is not None) and record['self_artifact']['valid']:
            self1.chmod(0o700); generation_rows = []
            self_runner = aarch64_runner(expected) or []
            for name, (text, stdout_expect, exit_expect) in FIXTURES.items():
                output = temporary/(name+'.generation2')
                q = run([*self_runner,self1, temporary/(name+'.sov'), '-o', output], root)
                facts = inspect(output, expected) if q['exit_code'] == 0 and output.is_file() else {'valid':False}
                execution = execute(output, expected, temporary, stdout_expect, exit_expect) if facts['valid'] else {'matched':False}
                generation_rows.append({'case':name,'build':q,'artifact':facts,'execution':execution})
            record['self_fixtures'] = generation_rows
            generation_b, generation_c = temporary/'generation-b', temporary/'generation-c'
            qb = run([*self_runner,self1,source,'-o',generation_b],root,600)
            qc = run([*self_runner,generation_b,source,'-o',generation_c],root,600) if qb['exit_code'] == 0 and generation_b.is_file() else {'exit_code':None}
            record['fixed_point'] = (qb['exit_code'] == 0 and qc['exit_code'] == 0
                                     and generation_b.is_file() and generation_c.is_file()
                                     and sha(self1) == sha(generation_b) == sha(generation_c))
            record['self_generations'] = {'b':qb,'c':qc}
            if record['fixed_point']: record['fixed_point_sha256'] = sha(generation_c)
            record['self_correct'] = record['fixed_point'] and record['self_reproducible'] and record['output_correct'] and all(r['execution']['matched'] for r in generation_rows)
        else:
            record['self_pending'] = 'generation must run on the intended platform and compile correct fixtures'
    record['repaired'] = all(record[k] for k in ('build','reproducible','output_correct','self_correct'))
    return record

def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--root', type=pathlib.Path, default=pathlib.Path(__file__).resolve().parents[2])
    parser.add_argument('--json', type=pathlib.Path); parser.add_argument('--only')
    args = parser.parse_args(); root = args.root.resolve(); bootstrap = root/'compilers/linux/compiler'
    registry = json.loads((root/'compilers/registry.json').read_text())
    selected = set(args.only.split(',')) if args.only else None; records = []
    dependencies = source_identity(root)
    with tempfile.TemporaryDirectory(prefix='sovren-fleet-gate-') as td:
        for entry in registry['entries']:
            if selected and entry['id'] not in selected: continue
            folder = pathlib.Path(td)/entry['id'].replace('/', '--'); folder.mkdir(parents=True)
            record = check(root, bootstrap, entry, folder); records.append(record)
            print(entry['id'], 'build', record['build'], 'repro', record['reproducible'],
                  'output', record['output_correct'], 'self', record['self_correct'], flush=True)
            if not record['build']:
                q = record.get('build_command', {})
                print('  ', (q.get('stderr') or q.get('stdout', ''))[:180].replace('\n',' | '), flush=True)
    stable = source_identity(root) == dependencies
    if not stable:
        for record in records: record['repaired'] = False
    report = {'schema':2, 'gate':'target-aware-driver-repair', 'bootstrap_sha256':sha(bootstrap),
              'source_dependencies':dependencies,'sources_unchanged_during_checks':stable,
              'drivers':len(records), 'built':sum(r['build'] for r in records),
              'reproducible':sum(r['reproducible'] for r in records),
              'correct_output':sum(r['output_correct'] for r in records),
              'correct_self':sum(r['self_correct'] for r in records),
              'repaired':sum(r['repaired'] for r in records), 'records':records}
    path = args.json or root/'work/repair/ledger-v2.json'; path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2)+'\n')
    print('Summary:', {k:v for k,v in report.items() if k != 'records'}, flush=True)
    return 0 if records and all(r['repaired'] for r in records) else 1

if __name__ == '__main__': raise SystemExit(main())
